import { SortPipePipe } from './sort-pipe.pipe';

describe('SortPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SortPipePipe();
    expect(pipe).toBeTruthy();
  });
});
