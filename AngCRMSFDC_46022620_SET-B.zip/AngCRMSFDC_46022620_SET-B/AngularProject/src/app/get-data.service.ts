import { Injectable } from '@angular/core';
import { HttpClient,HttpClientModule } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GetDataService {

  constructor(private httReq:HttpClient) {}
  //function returning data from JSON file
  getMobileData(){
    return this.httReq.get('../assets/Mobile.json');
  }
}
