import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortPipe'
})
export class SortPipePipe implements PipeTransform {

  transform(mobileData: any,para=''): any {
    if(para=='')
    return mobileData;
    //returning sorted data with respect to parameter passed
    return mobileData.sort(function(a,b){
      if(a[para]<b[para])
      return -1;
      else if(a[para]>b[para])
      return 1;
      else
      return 0;
    });
  }

}
