import { GetDataService } from './get-data.service';
import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularTest';
  //variable to store the complete Mobile Data List
  allMobileData;
  constructor(private ob:GetDataService){}
  ngOnInit(){
    //getting complete mobile data from SERVICE
    this.ob.getMobileData().subscribe(data=>this.allMobileData=data);
  }
  //function to Delete the Data from the List
  deleteData(mobile){
    this.allMobileData.splice(this.allMobileData.indexOf(mobile),1);
  }
}
