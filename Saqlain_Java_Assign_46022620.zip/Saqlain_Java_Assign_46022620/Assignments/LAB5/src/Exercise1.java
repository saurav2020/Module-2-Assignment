import javax.swing.*;    
import java.awt.event.*;    
class Exercise1 extends JFrame implements ActionListener{    
	JRadioButton rb1,rb2,rb3;    
	JButton b;    
	Exercise1(){      
		rb1=new JRadioButton("RED");    
		rb1.setBounds(100,50,100,30);      
		rb2=new JRadioButton("YELLOW");    
		rb2.setBounds(100,100,100,30); 
		rb3=new JRadioButton("GREEN");    
		rb3.setBounds(100,150,100,30); 
		ButtonGroup bg=new ButtonGroup();    
		bg.add(rb1);bg.add(rb2);bg.add(rb3);       
		add(rb1);add(rb2);add(rb3);   
		setSize(300,300);    
		rb1.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e){
				if(e.getStateChange()==1)
					System.out.println("STOP");  
			}
		});
		rb2.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e){
				if(e.getStateChange()==1)
					System.out.println("READY"); 
			}
		});
		rb3.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e){
				if(e.getStateChange()==1)
					System.out.println("GO"); 
			}
		});
		setLayout(null);    
		setVisible(true);    
	}    
	public void actionPerformed(ActionEvent e){    
		if(rb1.isSelected()){    
			System.out.println("STOP");    
		}    
		if(rb2.isSelected()){    
			System.out.println("READY");   
		}
		if(rb3.isSelected()){    
			System.out.println("GO");   
		}
	}    
	public static void main(String args[]){    
		new Exercise1();    
	}
}   