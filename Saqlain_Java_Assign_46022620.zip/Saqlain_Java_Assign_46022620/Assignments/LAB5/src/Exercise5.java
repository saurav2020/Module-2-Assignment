import java.util.Scanner;


class MyAgeException extends Exception{
	public MyAgeException(String s) {
		super(s);
	}
}

public class Exercise5 {

	public static void main(String[] args) {
		int age;
		Scanner in=new Scanner(System.in);
		
		try{
			System.out.print("Enter Age: ");
			if(in.nextInt()<=15)
				throw new MyAgeException("Age Validation Error");
			age=in.nextInt();
		}catch(Exception e){
			System.out.println("Exception Occured : " + e);
		}
		in.close();
	}

}
