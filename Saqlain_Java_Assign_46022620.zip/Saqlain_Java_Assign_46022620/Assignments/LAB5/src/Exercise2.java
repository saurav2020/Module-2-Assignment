import java.util.*;
public class Exercise2 {

	public static void main(String[] args) {
		
		Scanner in=new Scanner(System.in);
		System.out.println("Enter value of n : ");
		int n =in.nextInt();
		System.out.println("Using Recurcive : "+recurciveFibo(n));
		System.out.println("Using Recurcive : "+nonRecurciveFibo(n));
		in.close();
	}
	static int recurciveFibo(int n){
		if(n == 0){
			return 0;
		}
		if(n == 1 || n == 2){
				return 1;
			}
		return recurciveFibo(n-2) + recurciveFibo(n-1);
	}
	static int nonRecurciveFibo(int n){
		int first=1,second=1;int c=0;
		for(int i=0;i<n-2;i++){
			c=first+second;
			first=second;
			second=c;
		}
		return c;
	}
}

