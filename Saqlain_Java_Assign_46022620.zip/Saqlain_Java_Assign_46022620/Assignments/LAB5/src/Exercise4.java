import java.util.Scanner;


class MyException extends Exception{
	public MyException(String s) {
		super(s);
	}
}

public class Exercise4 {

	public static void main(String[] args) {
		String fname,lname;
		Scanner in=new Scanner(System.in);
		
		try{
			System.out.print("Enter First Name: ");
			fname=in.nextLine();
			System.out.print("Enter Last Name: ");
			lname=in.nextLine();
			if(fname.isEmpty() && lname.isEmpty())
				throw new MyException("Name Validation Error");
		}catch(Exception e){
			System.out.println("Exception Occured : " + e);
		}
		in.close();
	}

}
