import com.cg.eis.exception.EmployeeException;
public class Exercise6 {
	
	public static void main(String[] args) {
		double empSal[]={25000,12000,5000,2500,4500};
		try{
			for(int i=0;i<empSal.length;i++)
				if(empSal[i]<3000)
					throw new EmployeeException("Salary less than 3000");
			}catch(Exception e){
				System.out.println("Exception : "+e);
			}
	}
}

