import java.util.*;
public class Exercise2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Length of array : ");
		int n=in.nextInt();
		String strArr[]=new String[n];
		System.out.print("Enter Strings : ");
		for(int i=0;i<n;i++)
			strArr[i]=in.next();
		sortStringArr(strArr,n);
		in.close();
				
	}
	static void sortStringArr(String arr[],int n){
		Arrays.sort(arr);
		for(int i=0;i<=n/2;i++){
			arr[i]=arr[i].toUpperCase();
			System.out.println(arr[i]);
		}
		for(int i=(n/2)+1;i<n;i++){
			arr[i]=arr[i].toLowerCase();
			System.out.println(arr[i]);
		}
		
	}
}
