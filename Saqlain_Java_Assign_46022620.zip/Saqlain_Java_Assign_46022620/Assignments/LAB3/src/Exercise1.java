import java.util.*;
public class Exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		
		System.out.print("Enter Length of array : ");
		int n=in.nextInt();
		int arr[]=new int[n];
		System.out.print("Enter Elements of array : ");
		for(int i=0;i<n;i++)
			arr[i]=in.nextInt();
		System.out.print("Second Smallest Elements of array : "+getSecondSmallest(arr,n));
		in.close();
		
	}
	
	static int getSecondSmallest(int arr[],int n){
		Arrays.sort(arr);
		return arr[n-2]; 
	}

}
