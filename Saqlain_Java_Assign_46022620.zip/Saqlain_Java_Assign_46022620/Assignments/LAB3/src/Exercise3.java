import java.util.*;


public class Exercise3 {

	public static void main(String[] args) {
		
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Length of array : ");
		int n=in.nextInt();
		int arr[]=new int[n];
		System.out.print("Enter Array : ");
		for(int i=0;i<n;i++)
			arr[i]=in.nextInt();
		arr=getSorted(arr,n);
		for(int i=0;i<n;i++){
			System.out.print(arr[i]+" ");
			
		}
		in.close();

	}
	
	static int[] getSorted(int arr[],int n){
		String temp;
		for(int i=0;i<n;i++){
			temp=String.valueOf(arr[i]);
			String reverse = "";
			for(int j = temp.length() - 1; j >= 0; j--) {
			reverse = reverse + temp. charAt(j); }
			arr[i]=Integer.parseInt(reverse);
			//System.out.println(arr[i]);
		}
		Arrays.sort(arr);
		return arr;
	}

}
