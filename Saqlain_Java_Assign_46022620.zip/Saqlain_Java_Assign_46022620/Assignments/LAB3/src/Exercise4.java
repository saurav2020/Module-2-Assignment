import java.util.*;
public class Exercise4 {

	public static void main(String[] args) {
		
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Length of array : ");
		int n=in.nextInt();
		char arr[]=new char[n];
		System.out.print("Enter Char Array : ");
		for(int i=0;i<n;i++)
			arr[i]=in.next().charAt(0);
		String str="";
		for(int i=0;i<n;i++){
			if(str.indexOf(arr[i])>=0)
				continue;
			int c=getOccuracne(arr[i], arr);
			System.out.println(arr[i]+" Occurs "+c+" times");
			str+=arr[i];
		}
		in.close();
		
	}
	
	static int getOccuracne(char ch,char arr[]){
		int count=0;
		for(int i=0;i<arr.length;i++){
			if(ch==arr[i])
				count++;
		}
		return count;
	}

}
