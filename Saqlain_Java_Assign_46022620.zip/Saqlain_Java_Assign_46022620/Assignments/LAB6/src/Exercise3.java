import java.io.*;
import java.util.*;
public class Exercise3 {
	public static void main(String[] args) {
		try{
			File file=new File("file.txt");
			Scanner in=new Scanner(file);
			int lines=0,words=0,characters=0;
			while(in.hasNextLine()){
				lines++;
				String line=in.nextLine();
				int spaces=0;
				for(int i=0;i<line.length()-1;i++){
					if(line.charAt(i)==' ')
						spaces++;
					else
						characters++;
				}
				words+=spaces+1;
			}
			System.out.println("Number of Lines : "+lines);
			System.out.println("Number of Words : "+words);
			System.out.println("Number of Characters : "+characters);
			in.close();
		}catch(Exception e){
			System.out.println("File not Found");
		}
	}
}
