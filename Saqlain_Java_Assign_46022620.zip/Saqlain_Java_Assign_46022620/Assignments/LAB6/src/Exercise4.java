import java.io.*;
import java.util.*;
public class Exercise4 {
	public static void main(String[] args) {
		try{
			Scanner in=new Scanner(System.in);
			System.out.print("Enter the file name : ");
			String fileName=in.next()+".txt";
			File file=new File(fileName);
			System.out.println("File Exists : "+file.exists());
			System.out.println("File is Readable : "+file.canRead());
			System.out.println("File is Writable : "+file.canWrite());
			System.out.println("File Type of file : "+".txt");
			System.out.println("File Length in bytes : "+file.length());
			in.close();
		}catch(Exception e){
			System.out.println("Exception : "+e);
		}
	}
}
