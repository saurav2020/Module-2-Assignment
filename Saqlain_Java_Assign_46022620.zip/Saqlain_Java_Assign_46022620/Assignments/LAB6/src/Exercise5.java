import java.util.Scanner;


public class Exercise5 {
	
	static boolean isPositive(String str){
		
		for(int i=0;i<str.length()-1;i++){
			if(str.charAt(i)>str.charAt(i+1)){
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a String");
		String str=in.next();
		
		System.out.println("Entered String is Positive : "+isPositive(str));
		in.close();
		
		
	}
}
