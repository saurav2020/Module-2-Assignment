import java.util.Scanner;
public class Exercise7 {
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Username: ");
		String str=in.nextLine();
		System.out.println("Validation Result : "+validateUser(str));
		in.close();
	}
	static boolean validateUser(String str){
		
		String str1=str.substring(0, str.length()-4);
		if(str.endsWith("_job") && str1.length()>=8)
			return true;
		return false;
	}
}
