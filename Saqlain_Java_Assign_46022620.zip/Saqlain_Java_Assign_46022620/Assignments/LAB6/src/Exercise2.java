import java.io.*;
import java.util.*;
public class Exercise2 {
	public static void main(String[] args) {
		try{
			File file=new File("file.txt");
			Scanner in=new Scanner(file);
			int i=0;
			while(in.hasNextLine()){
				System.out.println(++i+". "+in.nextLine() );
			}
			in.close();
		}catch(Exception e){
			System.out.println("File not found");
		}
	}
}
