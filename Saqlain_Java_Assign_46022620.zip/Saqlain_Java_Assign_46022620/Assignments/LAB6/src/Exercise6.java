import java.time.*;
import java.util.Scanner;


public class Exercise6 {
	public static void main(String[] args) throws Exception{
		getDuration();
	}
	static void getDuration(){
		LocalDate curDate=LocalDate.now();
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Date(YYYY-MM-DD) : ");
		String str=in.next();
		LocalDate userDate=LocalDate.parse(str);
		int dayDiff=Math.abs(curDate.getDayOfYear()-userDate.getDayOfYear());
		int monthDiff=Math.abs(curDate.getMonthValue()-userDate.getMonthValue());
		int yearDiff=Math.abs(curDate.getYear()-userDate.getYear());
		if(yearDiff>0){
			monthDiff+=yearDiff*12;
			dayDiff+=yearDiff*365;
		}
		System.out.println("Days Duration : "+dayDiff);
		System.out.println("Month Duration : "+monthDiff);
		System.out.println("Year Duration : "+yearDiff);
		in.close();
	}
}
