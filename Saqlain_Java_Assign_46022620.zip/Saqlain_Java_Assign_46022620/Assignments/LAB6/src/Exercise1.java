import java.util.*;
public class Exercise1 {
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter String of Integers: ");
		String str=in.nextLine();
		int sum=0;
		StringTokenizer st=new StringTokenizer(str," ");
		while(st.hasMoreTokens()){
			String token=st.nextToken();
			System.out.print(token+", ");
			sum+=Integer.parseInt(token);
		}
		System.out.println("\nSum : "+sum);
		in.close();
	}
}
