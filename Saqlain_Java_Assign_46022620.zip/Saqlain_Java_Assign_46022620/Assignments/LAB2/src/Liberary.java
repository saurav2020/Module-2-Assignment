import java.util.Scanner;


abstract class Item{
	private int unique_id_num;
	private String title;
	public int getUnique_id_num() {
		return unique_id_num;
	}
	public String getTitle() {
		return title;
	}
	public int getNumCopies() {
		return numCopies;
	}
	private int numCopies;
	public Item(int unique_id_num, String title, int numCopies) {
		this.unique_id_num = unique_id_num;
		this.title = title;
		this.numCopies = numCopies;
	}
	@Override
	public String toString() {
		return "Item [unique_id_num=" + unique_id_num + ", title=" + title
				+ ", numCopies=" + numCopies + "]";
	}
}
abstract class WrittenItem extends Item{
	private String author;

	public String getAuthor() {
		return author;
	}

	public WrittenItem(String author,int unique_id_num, String title, int numCopies) {
		super(unique_id_num,title,numCopies);
		this.author = author;
	}
}
class Book extends WrittenItem{
	Book(String author,int unique_id_num, String title, int numCopies){
		super(author,unique_id_num,title,numCopies);
	}
	public void showData(){
		//System.out.println("Unique ID \t Title \t Author \t NumOfCopies");
		System.out.println(this.getUnique_id_num()+"\t"+this.getTitle()+"\t"+this.getAuthor()+"\t"+this.getNumCopies());
	}
	public int getUid(){
		return this.getUnique_id_num();
	}
}
class JournalPaper extends WrittenItem{
	JournalPaper(String author,int unique_id_num, String title, int numCopies){
		super(author,unique_id_num,title,numCopies);
	}
	public void showData(){
		//System.out.println("Unique ID \t Title \t Author \t NumOfCopies");
		System.out.println(this.getUnique_id_num()+"\t"+this.getTitle()+"\t"+this.getAuthor()+"\t"+this.getNumCopies());
	}
	public int getUid(){
		return this.getUnique_id_num();
	}
}
abstract class MediaItem extends Item{
	private int runtime;

	public int getRuntime() {
		return runtime;
	}

	public MediaItem(int runtime,int unique_id_num, String title, int numCopies) {
		super(unique_id_num,title,numCopies);
		this.runtime = runtime;
	}
}
class Video extends MediaItem{
	private String director;
	private String genre;
	public String getDirector() {
		return director;
	}
	public String getGenre() {
		return genre;
	}
	public int getYear() {
		return year;
	}
	private int year;
	public Video(int runtime, int unique_id_num, String title,int numCopies, String director, String genre, int year) {
		super(runtime, unique_id_num, title, numCopies);
		this.director = director;
		this.genre = genre;
		this.year = year;
	}
	public void showData(){
		//System.out.println("Unique ID \t Title \t RunTime \t NomOfCopies \t Director \t Genre \t Year");
		System.out.println(this.getUnique_id_num()+"\t"+this.getTitle()+"\t"+this.getRuntime()+"\t"+this.getNumCopies()+"\t"+this.getDirector()+"\t"+this.getGenre()+"\t"+this.getYear());
	}
	public int getUid(){
		return this.getUnique_id_num();
	}
}
class CD extends MediaItem{
	private String director;
	private String genre;
	public CD(int runtime, int unique_id_num, String title,int numCopies, String director, String genre) {
		super(runtime, unique_id_num, title, numCopies);
		this.director = director;
		this.genre = genre;
	}
	public void showData(){
		//System.out.println("Unique ID \t Title \t RunTime \t NomOfCopies \t Director \t Genre");
		System.out.println(this.getUnique_id_num()+"\t"+this.getTitle()+" "+this.getRuntime()+"\t"+this.getNumCopies()+"\t"+this.director+"\t"+this.genre);
	}
	public int getUid(){
		return this.getUnique_id_num();
	}
}
public class Liberary {
	public static void main(String[] args) {
		Book book[]=new Book[2];int booki=0;
		JournalPaper jp[]=new JournalPaper[2];int jpi=0;
		Video video[]=new Video[2];int videoi=0;
		CD cd[]=new CD[2];int cdi=0;
		
		Scanner in=new Scanner(System.in);
		
		while(true){
			System.out.print("Select Category(1. Book\t2. JournalPaper\t3.Video\t4.CD) : ");
			int category=in.nextInt();
			switch(category){
			case 1:
				System.out.println("Enter the uniqueID,title,author,num_Copies : ");
				int uid=in.nextInt();
				String title=in.next();
				String author=in.next();
				int numCopies=in.nextInt();
				book[booki]=new Book(author,uid,title,numCopies);
				booki++;
				break;
			case 2:
				System.out.println("Enter the uniqueID,title,author,num_Copies : ");
				uid=in.nextInt();
				title=in.next();
				author=in.next();
				numCopies=in.nextInt();
				jp[jpi]=new JournalPaper(author,uid,title,numCopies);
				jpi++;
				break;
			case 3:
				System.out.println("Enter the uniqueID,title,runtime,num_Copies,director,genre,year : ");
				uid=in.nextInt();
				title=in.next();
				int runtime=in.nextInt();
				numCopies=in.nextInt();
				String director=in.next();
				String genre=in.next();
				int year=in.nextInt();
				video[videoi]=new Video(runtime ,uid,title, numCopies, director, genre, year);
				videoi++;
				break;
			case 4:
				System.out.println("Enter the uniqueID,title,runtime,num_Copies,director,genre : ");
				uid=in.nextInt();
				title=in.next();
				runtime=in.nextInt();
				numCopies=in.nextInt();
				director=in.next();
				genre=in.next();
				cd[cdi]=new CD(runtime ,uid,title, numCopies, director, genre);
				cdi++;
				break;
			}
			System.out.print("Quit Entering(Y/N) : ");
			char choice=in.next().charAt(0);
			if(choice=='Y' || choice=='y')
				break;
		}
		System.out.println("Time to view the data : ");
		System.out.println();
		
		while(true){
			System.out.print("Select Category(1. Book\t2. JournalPaper\t3.Video\t4.CD) : ");
			int category=in.nextInt();
			switch(category){
			case 1:
				System.out.println("Enter the uniqueID : ");
				int uid=in.nextInt();
				for(int i=0;i<=booki;i++){
					if(book[i].getUid()==uid){
						book[i].showData();
						break;
					}
				}
				break;
			case 2:
				System.out.println("Enter the uniqueID : ");
				uid=in.nextInt();
				for(int i=0;i<=jpi;i++){
					if(jp[i].getUid()==uid){
						jp[i].showData();
						break;
					}
				}
				break;
			case 3:
				System.out.println("Enter the uniqueID : ");
				uid=in.nextInt();
				for(int i=0;i<=videoi;i++){
					if(video[i].getUid()==uid){
						video[i].showData();
						break;
					}
				}
				break;
			case 4:
				System.out.println("Enter the uniqueID : ");
				uid=in.nextInt();
				for(int i=0;i<=cdi;i++){
					if(cd[i].getUid()==uid){
						cd[i].showData();
						break;
					}
				}
				break;
				
			}
			System.out.print("Quit Viewing(Y/N) : ");
			char choice=in.next().charAt(0);
			if(choice=='Y' || choice=='y')
				break;
		}
		System.out.println("Program Terminated.......");
		
	}
}
