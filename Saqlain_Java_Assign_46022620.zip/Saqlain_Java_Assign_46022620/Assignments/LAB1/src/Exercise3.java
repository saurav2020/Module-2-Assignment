import java.util.Scanner;


public class Exercise3 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter the value of n : ");
		int n=in.nextInt();
		System.out.print("Number is increasing : "+checkNumber(n));
		in.close();
	}
	//Check if a number is an increasing number
	static boolean checkNumber(int number){
		int temp1=0,temp2=number%10;number/=10;
		while(number!=0){
			temp1=number%10;
			if(temp1>temp2)
				return false;
			temp2=temp1;
			number/=10;
		}
		return true;
	}

}
