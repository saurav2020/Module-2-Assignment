import java.util.Scanner;


public class Exercise4 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter the value of n : ");
		int n=in.nextInt();
		System.out.print("Number is Power of 2 : "+checkNumber(n));
		in.close();
	}
	//Checks if the entered number is a power of two or not 
	static boolean checkNumber(int n){
		for(int i=1;i<=n;i++){
			if(Math.pow(2, i)==n)
				return true;
		}
		return false;
	}

}
