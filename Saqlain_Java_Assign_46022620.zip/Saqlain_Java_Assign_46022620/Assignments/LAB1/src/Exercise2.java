import java.util.Scanner;


public class Exercise2 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter the value of n : ");
		int n=in.nextInt();
		System.out.print("Difference : "+calculateDifference(n));
		in.close();
	}
	//Calculate the difference
	static int calculateDifference(int n){
		int sum=0,sumOfSquare=0;
		for(int i=1;i<=n;i++){
			sum+=i;
			sumOfSquare+=i*i;
		}
		sum=sum*sum;
		int diff=sumOfSquare-sum;
		return diff;
	}

}
