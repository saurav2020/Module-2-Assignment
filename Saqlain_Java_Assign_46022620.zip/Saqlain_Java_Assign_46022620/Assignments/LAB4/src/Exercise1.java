import java.util.*;
public class Exercise1 {
	
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter number : ");
		int n=in.nextInt();
		System.out.print("Sum of cube of digits : "+getSum(n));
		in.close();
	}
	
	static int getSum(int n){
		int sum=0;
		while(n!=0){
			int temp=n%10;
			n=n/10;
			sum+=Math.pow(temp,3);
		}
		return sum;
	}
	
}
