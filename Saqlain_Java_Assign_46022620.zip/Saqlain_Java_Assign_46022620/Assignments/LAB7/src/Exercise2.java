import java.util.*;


public class Exercise2 {
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter size Chracter array : ");
		int n=in.nextInt();
		System.out.println("Enter a Chracter array : ");
		char charArr[]=new char[n];
		for(int i=0;i<n;i++){
			charArr[i]=in.next().charAt(0);
		}
		System.out.println(countCharacter(charArr));
		in.close();
	}
	
	static Map<Character,Integer> countCharacter(char[] charArr){
		Map<Character,Integer> map=new HashMap<Character, Integer>();
		
		for(int i=0;i<charArr.length;i++){
			if(map.containsKey(charArr[i]))
				continue;
			map.put(charArr[i], getCount(charArr[i],charArr));
		}
		
		return map;
	}
	
	static int getCount(char ch,char[] arr){
		int count=0;
		for(int i=0;i<arr.length;i++){
			if(arr[i]==ch)
				count++;
		}
		return count;
	}
	
}
