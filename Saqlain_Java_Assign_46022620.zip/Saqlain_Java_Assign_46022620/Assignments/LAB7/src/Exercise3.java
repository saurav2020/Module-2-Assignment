import java.util.*;


public class Exercise3 {
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter size of array : ");
		int n=in.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter array of numbers: ");
		for(int i=0;i<n;i++){
			arr[i]=in.nextInt();
		}
		System.out.println("The Resultant map is : "+getSquares(arr));
		in.close();
	}
	static Map<Integer,Integer> getSquares(int[] arr){
		Map<Integer,Integer> map=new HashMap<Integer, Integer>();
		for(int num:arr){
			int square=num*num;
			map.put(num, square);
		}
		return map;
	}
}
