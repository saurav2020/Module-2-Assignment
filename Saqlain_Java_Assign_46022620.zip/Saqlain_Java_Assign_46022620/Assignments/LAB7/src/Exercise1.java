import java.util.*;


public class Exercise1 {
	public static void main(String[] args) {
		HashMap<String, Integer> map=new HashMap<>();
		map.put("a", 10);
		map.put("b", 40);
		map.put("c", 30);
		map.put("d", 20);
		
		System.out.println(getValues(map));
	}
	static List<Integer> getValues(HashMap<String, Integer> map){
		List<Integer> list=new ArrayList<>(map.values());
		/*map.forEach((k,v)->{
			list.add(v);
		});*/
		//list.sort(null);
		Collections.sort(list);
		return list;
	}
}
